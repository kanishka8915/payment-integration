<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PayPal Transaction Cancel :: SPACE-O</title>
</head>
<body bgcolor="pink";>
	<h1 style="text-align:center; font-size:40px; margin-top:25%;">Your PayPal transaction has been canceled.</h1>
</body>
</html>